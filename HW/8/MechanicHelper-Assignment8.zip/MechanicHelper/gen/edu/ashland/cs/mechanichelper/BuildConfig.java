/** Automatically generated file. DO NOT MODIFY */
package edu.ashland.cs.mechanichelper;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}