import javax.swing.JOptionPane;
import java.util.Scanner;
public class Problem2{
	public static void main(String[] args){
		Scanner keyboard=new Scanner(System.in);
		System.out.println("What's the sentence: ");
		String input=keyboard.nextLine();
		int counter=0;
		
		for (char i=0;i<127;i++){
			for (int j=0;j<input.length();j++){
				if(input.charAt(j)==i){
					counter++;
				}
			}
			if(counter!=0){
				System.out.println(i+": "+counter);
			}
			counter=0;
		}

		
	}

}
