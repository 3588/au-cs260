import javax.swing.JOptionPane;
import java.util.Scanner;
public class Problem1{
	public static void main(String[] args){
		String input=JOptionPane.showInputDialog("What's the sentence");
		String temp=JOptionPane.showInputDialog("What's the char");
		char x=temp.charAt(0);
		int counter=0;
		for (int i=0;i<input.length();i++){
			if(input.charAt(i)==x){
				counter++;
			}
		}
		JOptionPane.showMessageDialog(null, "The "+x+" occured "+counter+" times in "+input);
		
	}

}
