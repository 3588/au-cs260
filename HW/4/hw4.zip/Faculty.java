package hw4;

public class Faculty extends Person implements Relatable{
	private String departmentString;
	private boolean tenured;
	public  Faculty() { departmentString="";tenured=false;}
	public  Faculty(int age, String lastNameString,String firstNameString,String departmentString,boolean tenured)
	{setAge(age); setLastName(lastNameString); setFirstName(firstNameString); this.departmentString=departmentString;this.tenured=tenured;}
	public  Faculty(String age, String lastNameString,String firstNameString,String departmentString,boolean tenured)
	{setAge(age); setLastName(lastNameString); setFirstName(firstNameString); this.departmentString=departmentString;this.tenured=tenured;}
	public void setDepartmentString(String departmentString) {this.departmentString=departmentString;}
	public void setTenured(boolean tenured) {this.tenured=tenured;}
	public String getDepartmentString() {return departmentString;}
	public boolean getTenured() {return tenured;}
	
	 public String toString() {
	      String str = "The Name is: " + getFirstName() +" " + getLastName()+", and age is "+getAge()+". work on "+departmentString;
	      if(tenured)
	    	  str+=" tenured";
	      return str;
	   }
	 public boolean equals(Faculty object2)
	   {
	      boolean status;
	      if (getAge() == object2.getAge() && getFirstName().equals(object2.getFirstName()) && getFirstName().equals(object2.getFirstName()) 
	    		  && this.departmentString.equals(object2.departmentString) && this.tenured==object2.tenured)
	         status = true;  
	      else
	         status = false;
	      return status;
	   }
	@Override
	public boolean larger(Person p) {
		if (p.getAge()<getAge())
		return true;
		else
			return false;
	}
	@Override
	public boolean smaller(Person p) {
		if (p.getAge()>getAge())
			return true;
			else
		return false;
	}
}
