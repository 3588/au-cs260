package hw4;

public class Driver {
	public static void prt(String str)
	{System.out.print(str);}
	public static void main(String[] args){
	Person p1 = new Person(55,"huang","junjun");
	Person p2 = new Person("66","cao","paul");
	prt("Test for Person class\n");
	System.out.println("get ago for p1: "+p1.getAge());
	System.out.println("get first name for p1: "+p1.getFirstName());
	System.out.println("get last name for p1: "+p1.getLastName());
	prt("set ago for p1 use int: "); p1.setAge(22);
	System.out.println("get new ago for p1: "+p1.getAge());
	prt("The data for p2 : "); prt(p2.toString()+"\n");
	prt("set ago for p2 use String: 33\n"); p2.setAge("33");
	prt("set first name for p2: Paul\n"); p2.setFirstName("Paul");
	prt("set last name for p2: Cao\n"); p2.setLastName("Cao");
	prt("The new data for p2 : "); prt(p2.toString()+"\n");
	if(p1.equals(p1))
		prt("p1 = p2\n");
	else
		prt("p1 != p2\n");
	
	prt("Test for Faculty and Interface class\n");
	Faculty pcaoFaculty = new Faculty("66","cao","paul","CS",false);
	Faculty bossFaculty = new Faculty("66","au","boss","CS",true);
	prt("The data for faculty1 : "); prt(pcaoFaculty.toString()+"\n");
	prt("The data for faculty2 : "); prt(bossFaculty.toString()+"\n");
	if(bossFaculty.getTenured())
		prt("the faculty2 is tenured");
	else
		prt("the faculty2 isn't tenured");
	prt("\nSet faculty2 tenured to not, and set new department"); bossFaculty.setTenured(false); bossFaculty.setDepartmentString("MATH");
	prt("\nThe new data for faculty2 : "); prt(bossFaculty.toString()+"\n");
	prt("\nThe new data for faculty1(set name, set ago) : "); pcaoFaculty.setAge(33);pcaoFaculty.setLastName("Paul");pcaoFaculty.setFirstName("Cao");
	prt("\nThe new data for faculty1 : "); prt(pcaoFaculty.toString()+"\n");
	
	if(pcaoFaculty.larger(bossFaculty))
		prt("\nthe ago faculty1>faculty2 ");
	if(pcaoFaculty.smaller(bossFaculty))
		prt("\nthe ago faculty1<faculty2 ");
	}
}
