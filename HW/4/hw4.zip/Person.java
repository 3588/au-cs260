package hw4;

public class Person {
	private int age;
	private String lastNameString, firstNameString;
	public  Person() { age=0; lastNameString="";firstNameString="";}
	public  Person(int age, String lastNameString,String firstNameString)
	{ this.age=age; this.lastNameString=lastNameString; this.firstNameString=firstNameString;}
	public  Person(String age, String lastNameString,String firstNameString)
	{ this.age=Integer.parseInt(age); this.lastNameString=lastNameString; this.firstNameString=firstNameString;}
	public void setAge(int age) { this.age=age;}
	public void setAge(String age) {this.age=Integer.parseInt(age);}
	public void setLastName(String lastNameString) {this.lastNameString=lastNameString;}
	public void setFirstName(String firstNameString) {this.firstNameString=firstNameString;}
	public int getAge() {return age;}
	public String getLastName() {return lastNameString;}
	public String getFirstName() {return firstNameString;}
	
	 public String toString() {
	      String str = "The Name is: " + firstNameString +" " + lastNameString+", and age is "+age;
	      return str;
	   }
	 public boolean equals(Person object2)
	   {
	      boolean status;
	      if (this.age == object2.getAge() && this.lastNameString.equals(object2.lastNameString) && this.firstNameString.equals(object2.firstNameString))
	         status = true;  
	      else
	         status = false; 
	      return status;
	   }
}
