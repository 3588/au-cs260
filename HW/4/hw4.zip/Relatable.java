package hw4;

public interface Relatable{
	public boolean larger(Person p);
	public boolean smaller(Person p);
}
