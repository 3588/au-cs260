/**
PROGRAM: Comment.java
Written by Paul Cao
This program calculates average GPA
*/

public class Comment
{
   /**
      The main method is the program's starting point.
   */
   
   public static void main(String[] args)        
   {
      double finalExam;    // Holds the final exam score
      double exams;   	// Hours holds the exams average
      String name;  	// Holds the student name

      // The Remainder of This Program is Omitted.
   }
}

