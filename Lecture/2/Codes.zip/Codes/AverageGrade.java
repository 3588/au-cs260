import javax.swing.JOptionPane;
public class AverageGrade{
	public static void main(String[] args){
		String fname,lname;
		fname=JOptionPane.showInputDialog("What is your first name?");
		lname=JOptionPane.showInputDialog("What is your last name?");
		
		double exam1, exam2, average;
		String grade;
		grade=JOptionPane.showInputDialog("What is your exam 1 score?");
		exam1=Double.parseDouble(grade);
		grade=JOptionPane.showInputDialog("What is your exam 2 score?");
		exam2=Double.parseDouble(grade);
		average=(exam1+exam2)/2.0;
		JOptionPane.showMessageDialog(null, fname+" "+lname+", your average grade is "+average);
		System.exit(0);
		
		
	}

}
