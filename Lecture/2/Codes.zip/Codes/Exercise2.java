import java.util.Scanner;
public class Exercise2{
	public static void main(String[] args){
		//get input
		int days;
		Scanner keyboard=new Scanner(System.in);
		do{
			System.out.print("How many days have you worked: ");
			days=keyboard.nextInt();
			if(days<1){
				System.out.println("Can't work less than a day! Lazy bug!");
			}
		}while(days<1);
		
		//display pay per day
		int pay=1;
		int total=0;
		for (int i=0;i<days;i++){
			System.out.println("Day "+ (i+1)+": "+pay);
			total+=pay;
			pay*=2;
		}
		
		System.out.println("\n******\nThe total is "+((double)total/100.0));
	}
}
