import java.util.Scanner;


public class ScannerExercise {
	public static void main(String[] args){
		double length, width;
		String name;
		Scanner keyboard=new Scanner(System.in);
		System.out.print("What is your first name: ");
		name=keyboard.next();
		System.out.print("Please enter the length: ");
		length=keyboard.nextDouble();
		System.out.print("Please enter the width: ");
		width=keyboard.nextDouble();
		
		System.out.println("Hey "+name+", your room is "+length*width+" square feet! Enjoy!");
	}

}
