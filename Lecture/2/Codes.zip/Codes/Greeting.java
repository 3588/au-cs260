import javax.swing.JOptionPane;
public class Greeting {
	public static void main(String[] args){
		String first=JOptionPane.showInputDialog("What is your first name?");
		String last=JOptionPane.showInputDialog("What's your last name?");
		JOptionPane.showMessageDialog(null, "Good morning "+first.toUpperCase().charAt(0)+last.toUpperCase().charAt(0));
		
		System.exit(0);
	}

}
