import java.text.DecimalFormat;
import java.util.Scanner;

public class Formatter {
	public static void main(String[] args) {
		double myValue;
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("What is the value: ");
		myValue = keyboard.nextDouble();
		
		DecimalFormat formatter = new DecimalFormat("#0.00");
		
		System.out.println("The value is "+formatter.format(myValue));

	}
}
