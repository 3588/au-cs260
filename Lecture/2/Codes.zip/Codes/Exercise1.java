import java.text.DecimalFormat;
public class Exercise1{
	public static void main(String[] args){
		DecimalFormat formatter=new DecimalFormat(".000000");
		int num=1;
		int dem=30;
		double total=0;
		for (int i=0;i<30;i++){
			total+=(double)num/(double)dem;
			num++;
			dem--;
		}
		System.out.println("Sum of the series is "+formatter.format(total));
	}
}
