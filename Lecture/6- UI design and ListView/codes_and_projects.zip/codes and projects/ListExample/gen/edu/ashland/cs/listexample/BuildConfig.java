/** Automatically generated file. DO NOT MODIFY */
package edu.ashland.cs.listexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}