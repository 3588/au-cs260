/** Automatically generated file. DO NOT MODIFY */
package edu.ashland.acm.aucolorpicker;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}