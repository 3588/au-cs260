import java.util.Random;

import javax.swing.JOptionPane;


public class GuessingGame {
	public static void main(String[] args){
		JOptionPane.showMessageDialog(null, "Welcome to our simple dice game!" +
				"\n Press ok to continue");
		boolean end=false;
		do{
			String input=JOptionPane.showInputDialog("What number do you guess?");
			int result=randomDice();
			if(result!=Integer.parseInt(input)){
				JOptionPane.showMessageDialog(null, "Too bad. it is " +result+
						"\nTry again!");
				
			}
			else{
				JOptionPane.showMessageDialog(null, "Hey you got it!");
				end=true;
			}
		}while(end==false);
		
		System.exit(0);
		
	}
	
	public static int randomDice(){
		Random r=new Random();
		return r.nextInt(6)+1;
	}
}
