import java.util.Random;
public class Exercise4{
	public static void main(String[] args){
		final int SIZE=5;
		Random r=new Random();
		double[] original=new double[SIZE];
		for (int i=0;i<SIZE;i++){
			original[i]=r.nextDouble();
			System.out.print(original[i]+"\t");
		}
		System.out.println("\nThe max is "+findMax(original));
		
		double[] newArray =square(original);
		for (int i=0;i<SIZE;i++){
			System.out.print(newArray[i]+"\t");
		}
	}
	
	public static double findMax(double[] a){
		double max=a[0];
		for (int i=1;i<a.length;i++){
			if(max<a[i]){
				max=a[i];
			}
		}
		return max;
	}
	
	public static double[] square(double[] a){
		double[] squared= new double[a.length];
		for (int i=0;i<squared.length;i++){
			squared[i]=a[i]*a[i];
		}
		return squared;
	}
}
