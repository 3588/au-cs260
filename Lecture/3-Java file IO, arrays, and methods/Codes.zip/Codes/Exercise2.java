import java.util.Scanner;


public class Exercise2 {
	public static void main(String[] args){
		int size;
		Scanner keyboard=new Scanner(System.in);
		System.out.print("What is the size: ");
		size=keyboard.nextInt();
		
		double[] a1, a2;
		a1=new double[size];
		a2=new double[size];
		
		System.out.println("Enter the data for array 1 below");
		
		for (int i=0;i<size;i++){
			a1[i]=keyboard.nextDouble();
		}
		System.out.println("Enter the data for array 2 below");
		
		for (int i=0;i<size;i++){
			a2[i]=keyboard.nextDouble();
		}		
		
		boolean result=true;
		//compare
		for (int i=0;i<size;i++){
			if(a1[i]!=a2[i]){
				result=false;
				break;
			}
		}
		if(result==false){
			System.out.println("The arrays are different!");
		}
		else{
			System.out.println("The arrays are the same!");
		}
		
	}

}
