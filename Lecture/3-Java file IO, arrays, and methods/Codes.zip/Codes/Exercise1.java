import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Exercise1 {
	public static void main(String[] args) throws IOException{
		//read in the file name
		String filename;
		System.out.print("What is the name of the file: ");
		Scanner keyboard = new Scanner(System.in);
		filename=keyboard.next();
		
		//read in the content of the file and convert to upper cases
		File fin=new File(filename);
		Scanner fileInput=new Scanner(fin);
		while(fileInput.hasNext()){
			String temp=fileInput.nextLine();
			System.out.println(temp.toUpperCase());
		}
	}
	

}
