import java.io.File;
import java.io.IOException;
import java.util.Scanner;


public class Exercise3 {
	public static void main(String[] args) throws IOException{
		File file=new File("data.txt");
		Scanner fin=new Scanner(file);
		int[][] x=new int[5][10];
		
		int total=0;
		for (int i=0;i<5;i++){
			for (int j=0;j<10;j++){
				x[i][j]=fin.nextInt();
				System.out.print(x[i][j]+"\t");
				total+=x[i][j];
			}
			System.out.println();
		}
		
		System.out.println("the total of the array is "+total);
		
	}

}
