package edu.ashland.cs.webadvisor;
//m
import android.app.Activity;
import android.os.Bundle;

public class FavoriteClass extends Activity {
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favoriteclass);
        
	}
}
