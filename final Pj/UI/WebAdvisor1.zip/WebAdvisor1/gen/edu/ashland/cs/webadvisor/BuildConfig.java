/** Automatically generated file. DO NOT MODIFY */
package edu.ashland.cs.webadvisor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}